﻿// Lab #1, Step #4
//using System;

//namespace Lab1.Models
//{
//    public class HomeViewModel
//    {
//        public string Message { get; set; }
//    }
//}
