﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;

//namespace Lab4.Models
//{
//    // Lab #4, Step #5a
//    public interface IEmployeeRepository
//    {
//        List<Employee> GetAll();
//        Employee Get(int id);
//    }
//}
