using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using Lab4.Models;

namespace Lab4.Controllers
{
    public class EmployeeController : Controller
    {
        // Lab #4, Step #8a
        //private IEmployeeRepository _repository;

        // Lab #4, Step #8a
        //public EmployeeController() : this(new EmployeeRepository())
        //{
        //}

        // Lab #4, Step #8a
        //public EmployeeController(IEmployeeRepository repository)
        //{
        //    _repository = repository;
        //}

        //
        // GET: /Employee/

        public ActionResult Index()
        {
            return View();

            // Lab #4, Step #5b
            //var employees = _repository.GetAll();

            // Lab #4, Step #5c
            //return View(employees);
        }

        //
        // GET: /Employee/Details/5

        public ActionResult Details(int id)
        {
            return View();

            // Lab #4, Step #8a
            //var employee = _repository.Get(id);

            // Lab #4, Step #8a
            //return View(employee);
        }

        //
        // GET: /Employee/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Employee/Create

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Employee/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Employee/Edit/5

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
