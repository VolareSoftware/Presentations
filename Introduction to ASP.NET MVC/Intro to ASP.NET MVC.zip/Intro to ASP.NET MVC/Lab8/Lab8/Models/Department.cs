﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;

//namespace Lab8.Models
//{
//    // Lab #8, Step #1
//    public class Department
//    {
//        public string Name { get; set; }
//    }
//}
