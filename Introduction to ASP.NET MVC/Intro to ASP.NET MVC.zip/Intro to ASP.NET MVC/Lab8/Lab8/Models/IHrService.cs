//using System.Collections.Generic;

//namespace Lab8.Models
//{
//    public interface IHrService
//    {
//        // Lab #8, Step #3
//        List<Department> GetAllDepartments();
//    }
//}